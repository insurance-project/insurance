package com.insurance.dao;

import com.insurance.model.insurance.PredictProfit;

public interface PredictProfitDAO {
	public void InsertPredictProfit(PredictProfit predictProfit) throws Exception;

}
