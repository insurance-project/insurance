package com.insurance.model.insurance;


/**
 * @author ���ֿ�
 * @version 1.0
 * @created 02-5-2021 ���� 11:51:58
 */
public interface InsuranceList {
	
	public boolean add(Insurance Insurance);	
	public boolean delete(Insurance Insurance);

}