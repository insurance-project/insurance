package com.insurance.model.insurance;

public class PredictProfit {
	private int predictProfitID; 
	private int profit; // �씠�씡 = 蹂댄뿕猷�
	private int subscribers; // �삁�긽 媛��엯�옄�닔
	private int totalProfit; // profit * subscribers
	
	public PredictProfit()
	{
		
	}
	
	public int getProfit() {
		return profit;
	}

	public void setProfit(int profit) {
		this.profit = profit;
	}

	public int getSubscribers() {
		return subscribers;
	}

	public void setSubscribers(int subscribers) {
		this.subscribers = subscribers;
	}

	public int getTotalProfit() {
		return totalProfit;
	}

	public void setTotalProfit(int totalProfit) {
		this.totalProfit = totalProfit;
	}

	public int getPredictProfitID() {
		return predictProfitID;
	}

	public void setPredictProfitID(int predictProfitID) {
		this.predictProfitID = predictProfitID;
	}

	

}
