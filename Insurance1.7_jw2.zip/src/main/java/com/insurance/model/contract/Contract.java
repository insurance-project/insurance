package com.insurance.model.contract;


import com.insurance.model.insurance.Insurance;

public class Contract {
	private String customerName;
	private Insurance insurance;
	//private Date insuranceContractDate;
	//private Date insuranceExpiryDate;
	//private Insurance InsKind;
	private String date1;


	
	
	
//	public void setInsuranceExpiryDate(Date insuranceExpiryDate) {
//		this.insuranceExpiryDate = insuranceExpiryDate;
//	}
//	
//	public Date getInsuranceContractDate() {
//		return insuranceContractDate;
//	}
//	
//	public void setInsuranceContractDate(Date insuranceContractDate) {
//		this.insuranceContractDate = insuranceContractDate;
//	}
//	
//	public Date getInsuranceExpiryDate() {
//		return insuranceExpiryDate;
//	}
//	

	
	public Insurance getInsurance() {
		return insurance;
	}

	public void setInsurance(Insurance insurance) {
		this.insurance = insurance;
	}

	public String getDate1() {
		return date1;
	}

	public void setDate1(String date1) {
		this.date1 = date1;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

//	public String getMonth() {
//		return month;
//	}
//
//	public void setMonth(String month) {
//		this.month = month;
//	}
//
//	public String getIll() {
//		return ill;
//	}
//
//	public void setIll(String ill) {
//		this.ill = ill;
//	}
//
//	public Customer getName() {
//		return name;
//	}
//
//	public void setName(Customer name) {
//		this.name = name;
//	}


	
	
	
	
	
}