package com.insurance.model.contract;

public interface ContractList {
	public boolean add(Contract Contract);	
	public boolean delete(Contract Contract);
}
