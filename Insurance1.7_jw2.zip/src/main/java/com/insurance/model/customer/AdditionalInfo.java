package com.insurance.model.customer;
public class AdditionalInfo {

	private int carGrade;
	private int buildingGrade;
	private int diseaseGrade;
	
	public int getCarGrade() {
		return carGrade;
	}
	public void setCarGrade(int carGrade) {
		this.carGrade = carGrade;
	}
	public int getBuildingGrade() {
		return buildingGrade;
	}
	public void setBuildingGrade(int buildingGrade) {
		this.buildingGrade = buildingGrade;
	}
	public int getDiseaseGrade() {
		return diseaseGrade;
	}
	public void setDiseaseGrade(int diseaseGrade) {
		this.diseaseGrade = diseaseGrade;	
	}

}