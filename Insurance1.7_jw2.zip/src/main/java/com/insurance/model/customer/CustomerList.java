package com.insurance.model.customer;


/**
 * @author ���ֿ�
 * @version 1.0
 * @created 02-5-2021 ���� 11:51:58
 */
public interface CustomerList {
	
	public boolean add(Customer customer);	
	public boolean delete(Customer customer);

}